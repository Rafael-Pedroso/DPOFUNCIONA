# Botsonic Wordpress Plugin for widget

- zip the folder to install as a plugin